//
// Created by louis on 08/02/2025.
//

#ifndef SHOP_H
#define SHOP_H

#include "joueur.h"
#define MAX_ITEM_NAME 20
void handleItemTransaction(Player *player, int itemChoice, int isBuying);

#endif //SHOP_H
